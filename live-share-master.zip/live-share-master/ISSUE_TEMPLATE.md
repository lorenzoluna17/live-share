<!-- 
For Visual Studio problems/feedback, please use the "Report a Problem..." feature built into the tool. See https://aka.ms/vsls-vsproblem.

For VS Code issues, attach verbose logs as follows:
1. Press F1 (or Ctrl+Shift+P / Cmd+Shift+P), type "export logs" and run the "Live Share: Export Logs" command.
2. Drag and drop the zip to the issue on this screen and wait for it to upload before creating the issue.

For feature requests, please include enough of this same info so we know if the request is tool or language/platform specific.
-->

**Product and Version** [VS/VSCode]:
**OS Version** [macOS/Windows]:
**Live Share Extension Version**: 
**Target Platform or Language** [e.g. Node.js]:

**Steps to Reproduce / Scenario:**

1.
2.

