# Moved

This document has moved to [a new location](https://aka.ms/vsls-docs/join).
